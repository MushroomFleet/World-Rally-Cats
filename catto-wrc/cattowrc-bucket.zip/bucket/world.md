# Cat World Rally Championship - World Building

## Physical Setting and Geography

### The CWRC Universe
The Cat World Rally Championship exists in an alternate Earth where anthropomorphic felines have evolved as the dominant intelligent species. This world mirrors our own geographically—same continents, mountain ranges, and climate zones—but human civilization has been replaced by feline societies that have developed parallel technological and cultural evolution.

**Key Rally Locations:**
- **Monte-Carlo (Gap/Monaco):** Alpine terrain with unpredictable winter conditions mixing snow, ice, and dry tarmac. Historic principality remains gambling and luxury hub.
- **Sweden (Umeå):** Frozen northern landscapes with ice-covered lakes and forest stages. Temperatures reach -20°C, testing equipment and drivers.
- **Kenya (Nairobi):** Volcanic gravel, fesh-fesh dust, and extreme heat. Wildlife coexistence is normal—lions, leopards, and domestic cats share mutual respect.
- **Croatia (Zagreb):** Smooth tarmac mountain roads through Balkan highlands. Technical precision over raw speed.
- **Portugal (Coimbra):** Abrasive granite gravel that destroys tires. Rocky mountain stages with dramatic elevation changes.
- **Sardinia (Alghero):** Mediterranean island heat and sharp granite rocks. Technical, tire-management focused.
- **Poland (Mikołajki):** Fast, flowing gravel through lake districts and forests. High-speed commitment stages.

### Rally Infrastructure
**Service Parks:** Temporary cities erected for each rally, featuring:
- Climate-controlled garages with precision measurement tools
- Hospitality zones serving species-appropriate cuisine
- Media centers with multilingual broadcasting (purring undertones in some languages)
- Fan zones where spectators' night-vision allows evening stage viewing

**Stage Routes:** Public roads closed for competition, ranging from narrow mountain passes to wide-open desert tracks. Safety protocols account for feline reflexes (barriers placed closer to roads due to superior reaction times).

## Historical Context and Timeline

### Evolution of Motorsport
Feline societies developed internal combustion engines in parallel timeline to human history (early 1900s). However, their superior night vision, reflexes (5x faster than humans), and spatial awareness accelerated motorsport development.

**Key Milestones:**
- **1951:** First World Rally Cat Championship (predecessor to CWRC)
- **1973:** All-wheel-drive technology introduced, revolutionizing rally
- **1997:** Turbocharging becomes standard, creating "golden era"
- **2017:** Hybrid regulations introduced for environmental concerns
- **2024:** Current Rally1 hybrid formula established
- **2026:** This season—third year under hybrid regulations

### Recent Championship History
- **2019:** Ott Tänak wins title with M-Sport Ford (his only championship)
- **2020-2022:** Disrupted seasons (global catnip shortage crisis—not elaborated)
- **2023:** Kuro Nakamura wins first championship (Toyota)
- **2024:** Kuro defends title (second championship)
- **2025:** Thierry Neuville finally wins championship (Hyundai) after years of heartbreak
- **2026:** Current season—Ott leading championship fight

## Cultural Norms and Social Structures

### Feline Society
**Species Integration:** Multiple cat breeds coexist peacefully. Bombays, Korats, Turkish Vans, and wildcats all participate equally. Breed characteristics (Korat heat sensitivity, Van water affinity, Bombay night vision) create natural advantages/disadvantages in different conditions.

**Language:** Universal language exists (similar to English) with regional dialects. Emotional states sometimes expressed through species-specific vocalizations:
- Victory howls/yowls are culturally accepted celebrations
- Purring indicates contentment (rarely seen in competitive rally environment)
- Hissing is extreme disrespect (never occurs in professional CWRC)

**Hierarchies:** Merit-based rather than breed-based. Championship success, technical skill, and tactical intelligence determine respect. Team principals (often human in this universe—indicating some human-cat coexistence) manage operations while cat drivers provide performance.

### Rally Culture
**Fan Engagement:** Massive global following. Night stages particularly popular due to feline night-vision allowing spectator viewing in darkness. Fans travel internationally, creating "rally tourism" economy.

**National Pride:** Strong national team support. Finnish fans worship rally (Finland's unofficial religion). Belgian fans desperate for Thierry's success. Japanese fans revere Kuro's precision.

**Traditions:**
- Pre-rally blessing ceremonies (Shinto shrines in Japan, Catholic churches in Europe)
- Post-rally team dinners mandatory (social bonding over competitive isolation)
- Champagne sprays on podiums (modified for feline physiology—less alcohol sensitivity)
- Respectful rivalry (competitors race hard, celebrate together)

## Technology Level

### Rally1 Hybrid Technology (2026 Specification)
**Advanced Systems:**
- **Hybrid Power:** 1.6L turbo engine (380 HP) + 100kW electric motor (134 HP) = 500 HP total
- **Energy Recovery:** Regenerative braking recharges battery mid-stage
- **Strategic Deployment:** Driver-controlled electric boost via steering wheel button
- **Telemetry:** Real-time data transmission to team engineers
- **All-Wheel Drive:** Active center differential with electronic control
- **Sequential Transmission:** Paddle-shifted 6-speed for maximum efficiency

**Cat-Specific Adaptations:**
- Cockpit design accommodates tails (wraparound safety harness, tail positioning channels)
- Helmet audio dampening protects sensitive feline hearing from engine noise
- Climate control systems account for fur insulation (critical for Bombays in hot climates)
- Dashboard displays optimized for feline visual spectrum (enhanced yellows/blues, reduced reds)
- Seats contoured for digitigrade leg structure
- Whisker protection in roll cage design

**Manufacturing:** Three factory teams (Toyota, Hyundai, M-Sport Ford) develop cars under strict technical regulations. Budget caps attempt to level playing field, but manufacturer resources vary significantly.

### Broader Technology
World technology parallels modern Earth (2026 equivalent):
- Smartphones and social media (drivers have massive followings)
- Hybrid/electric road cars becoming standard
- Advanced materials science (carbon fiber, titanium)
- Satellite navigation and GPS (though rally relies on traditional pacenotes)

## Political and Economic Systems

### Governing Bodies
**FIA (Fédération Internationale de l'Automobile):** Global motorsport authority setting technical regulations, safety standards, and sporting rules. Multinational organization with representatives from all competing nations.

**WRC Promoter:** Commercial rights holder organizing calendar, broadcasting, and sponsorship. Balances traditional European rallies with global expansion (Kenya, Japan, Chile).

### Team Structures
**Factory Teams (Manufacturer-backed):**
- **Toyota Gazoo Racing:** Japanese precision, massive budget, kaizen philosophy
- **Hyundai Shell Mobis WRT:** Korean-European hybrid, passionate culture, significant resources
- **M-Sport Ford WRT:** British privateer team, limited budget, maximum ingenuity

**Economic Realities:**
- Factory teams: €25-30 million annual budgets
- M-Sport: €15-18 million budget (requires creative solutions)
- Prize money minimal—prestige and manufacturer marketing are true rewards
- Sponsorship crucial (Shell, Mobis, Red Bull, Castrol provide millions)

### Championship Economics
**Revenue Sources:**
- Broadcasting rights (global TV coverage)
- Manufacturer marketing budgets (cars are rolling advertisements)
- Rally host fees (countries pay to host rounds)
- Merchandise and licensing

**Cost Control:** Hybrid components standardized to reduce expenses. Teams limited to specific testing days. Parts homologation prevents expensive development wars.

## Unique Aspects of This Universe

### Human-Cat Coexistence
Humans exist as support species in this universe—team principals, engineers, and technical directors are often human, suggesting historical partnership rather than competition. Relationship is collaborative; humans provide organizational/technical expertise, cats provide performance capabilities.

### Biological Advantages in Motorsport
**Feline Traits Enhancing Rally:**
- **Reflexes:** 5x faster than human baseline, enabling split-second corrections
- **Night Vision:** Tapetum lucidum allows superior low-light performance
- **Spatial Awareness:** Whiskers provide additional environmental feedback
- **Balance:** Inner ear structure and tail provide exceptional proprioception
- **Hearing:** Detect engine notes/mechanical issues humans would miss

**Feline Challenges:**
- **Heat Sensitivity:** Dark fur (Bombays) absorbs dangerous heat
- **Cold Sensitivity:** Some breeds (Korats) struggle in extreme winter
- **Sensory Overload:** Loud engines require hearing protection
- **Territorial Instincts:** Require professionalism to override competitive aggression

### Philosophical Differences by Nationality
**Japanese (Toyota):** *Kaizen* (continuous improvement), precision over flash, team harmony, respectful competition

**Belgian (Neuville):** Passionate aggression, emotional expression, racing as art form, never-surrender mentality

**Estonian (Tänak):** Minimalist efficiency, emotional restraint, speaking through actions, Nordic stoicism

**Finnish (Pajari):** Fearless commitment, sideways-or-nothing, rally as existential expression, death metal soundtracks

**French (Fourmaux):** Intellectual approach, architectural precision, philosophical framing, aesthetic appreciation

**Luxembourg (Munster):** Chaotic joy, improvisation, social bonding, rally as adventure

### The Rally Community
Despite fierce competition, CWRC maintains familial atmosphere. Drivers compete ruthlessly on stages, then share meals and stories in service parks. Respect is paramount—cheap victories are hollow, hard-fought defeats honorable. This "rally family" distinguishes CWRC from circuit racing's cutthroat politics.

### Media and Public Perception
Rally drivers are international celebrities. Kuro's precision inspires Japanese youth. Thierry's passion makes him Belgian folk hero. Sami represents Finnish rally resurrection. Social media amplifies personalities—Grégoire's antics go viral, Ott's stoicism becomes meme material.

**Broadcasting:** 24/7 coverage during rally weekends. Onboard cameras, helicopter footage, stage-end interviews. Commentators analyze hybrid deployment strategies, tire choices, and psychological warfare. Night stages broadcast globally using feline spectators' phone cameras (night-vision advantage).

### Environmental Considerations
Hybrid regulations reflect growing environmental awareness in feline societies. Electric power reduces emissions, regenerative braking recovers energy. Future regulations may mandate full electric (debate ongoing—purists argue engine sound is rally's soul).

---

**The CWRC Universe Summary:**
A world where feline evolution created societies mirroring human development, but with biological advantages that make motorsport more spectacular. Technology, culture, and competition blend into sport that tests physical limits, strategic thinking, and machine mastery. Rally's unique demands—constantly changing conditions, public roads, endurance over days—create perfect environment for feline capabilities to shine. The result: athletic prowess meets mechanical engineering in 13 rounds of global championship drama.