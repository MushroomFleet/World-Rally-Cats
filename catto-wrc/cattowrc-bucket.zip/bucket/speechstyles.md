# CWRC Character Speech Styles

## Kuro "The Shadow" Nakamura

- **Vocabulary Level**: Formal, precise, minimal. Uses technical rally terms accurately. Avoids casual speech even with teammates.

- **Sentence Structure**: Short, declarative sentences. Subject-verb-object simplicity. Rarely uses compound sentences. Japanese-influenced directness.

- **Verbal Tics**: 
  - "Expected result."
  - "Consistency defeats luck."
  - "Thank you." (most common phrase, delivered with slight bow)
  - Pauses between sentences (calculates exact words needed)
  - Never uses contractions ("cannot" not "can't")

- **Emotional Expression**: Extreme restraint. Emotions conveyed through micro-expressions and eye intensity rather than words. Victory speeches under 15 words. Never raises voice. Silence is preferred response.

- **Influence**: Japanese cultural restraint, corporate Toyota discipline, mathematical precision. Speaks like engineer writing technical report. English is flawless but slightly formal (learned academically).

**Example dialogue**: 
"The car performed within expected parameters. The team executed strategy correctly. Second place was optimal outcome given variables. Thank you."

---

## Sami "Wildcard" Pajari

- **Vocabulary Level**: Casual, enthusiastic, peppered with Finnish expressions and rally slang. Uses "brother/sister" universally.

- **Sentence Structure**: Energetic fragments and run-ons. Thoughts tumble out rapidly. Exclamation points implied constantly. Stream-of-consciousness when excited.

- **Verbal Tics**:
  - "Brother/sister!" (addressing everyone)
  - "THIS IS WHAT RALLY SHOULD BE!"
  - "If you're not sideways, are you even rallying?"
  - "PERKELE!" (Finnish curse when frustrated)
  - Enthusiastic capitalization in tone
  - Makes engine noises mid-conversation

- **Emotional Expression**: Completely open. Shouts when happy, cries when sad, roars when angry. Wears heart on sleeve. Grins maniacally during chaos descriptions. Voice rises with excitement.

- **Influence**: Finnish directness, youth culture, metal music energy. English with slight Finnish accent (rolling R's, precise consonants). Code-switches to Finnish with Enni under stress.

**Example dialogue**:
"Brother, that stage was INSANE! We were completely sideways through the whole section—like VROOOOM, sliding, catching, FLAT-OUT! Enni kept saying 'CALM, CALM' but where's the fun in calm, you know? This is RALLY!"

---

## Thierry "The Warrior" Neuville

- **Vocabulary Level**: Passionate, competitive, bilingual. Mixes French and English mid-sentence when emotional. Uses dramatic rally terminology.

- **Sentence Structure**: Emphatic statements. Rhetorical questions when frustrated. French sentence structure occasionally bleeds into English. Dramatic pauses for effect.

- **Verbal Tics**:
  - "Second place is first loser."
  - "TROIS POINT SEPT!" (or other time gaps, shouted in French)
  - "I've had enough of losing."
  - Switches to French-Flemish hybrid when angry: "C'est pas possible!"
  - Victory howls (Korat yowls) after stage wins
  - "This is MY surface!" (on tarmac)

- **Emotional Expression**: Highly demonstrative. Shouts, gestures dramatically, stares unblinking at rivals. Voice modulates wildly—whisper-quiet intensity to shouting fury. Celebratory howls are literal vocalizations.

- **Influence**: Belgian passion, French linguistic flair, years of championship heartbreak creating edge. Bilingual brain creates unique speech patterns. Flemish directness meets French drama.

**Example dialogue**:
"THREE POINT SEVEN SECONDS! Do you understand? TROIS POINT SEPT! This close—THIS CLOSE—and what? Nothing! Second place again! Non, non, non. I am finished with second. Tomorrow, we attack. Everything."

---

## Ott "The Ice King" Tänak

- **Vocabulary Level**: Minimal, technical, blunt. Shortest possible words. Avoids adjectives. Pure efficiency.

- **Sentence Structure**: Sentence fragments. Subject and verb, nothing more. Sometimes just single words. Periods implied everywhere.

- **Verbal Tics**:
  - "Fast is fast."
  - "Was good." (highest praise)
  - "No." (complete answer)
  - Grunts as full responses
  - "..." (literal silence)
  - Estonian directness to the point of seeming rude

- **Emotional Expression**: Nearly none. Flat delivery regardless of context. Slight fist-pump is maximum celebration. Occasional eye-roll (extreme emotion). Never explains, never elaborates. Silence speaks volumes.

- **Influence**: Estonian minimalism, Nordic stoicism, engineer's efficiency. English is functional tool, not expression medium. Russian undertones occasionally (multilingual background). Every word has cost—spends them carefully.

**Example dialogue**:
"Car was good. Martin was good. Hyundai was good. Thank you." 
[If pressed for more]: "What more? We won. Is enough."

---

## Adrien "The Architect" Fourmaux

- **Vocabulary Level**: Intellectual, metaphorical, architectural terms. Sophisticated vocabulary. French philosophical influence.

- **Sentence Structure**: Complex, flowing sentences. Subordinate clauses. Metaphorical constructions. Academic phrasing. Occasionally over-explains.

- **Verbal Tics**:
  - "The car and I must become one organism."
  - Architectural metaphors: "Gothic arch approach, not Brutalist"
  - French philosopher quotes: "As Camus said..."
  - "Fascinating load distribution" (about anything structural)
  - "Blanche" (his car's name, used in third person)
  - "Precisely" and "Exactly" as emphasis

- **Emotional Expression**: Intellectualized emotion. Describes feelings through metaphor and philosophy. Growing confidence shows in sentence certainty. Doubt creates hesitation and qualification. Tears after victories (different colors from heterochromia eyes—described poetically).

- **Influence**: French education, aerospace engineering background, architectural obsession. English is fluent but retains French syntax and philosophical framing. Treats language as precision instrument.

**Example dialogue**:
"You see, the corner requires a Gothic arch approach—structural integrity through distributed load, yes? The car's weight must flow through the apex like flying buttress transfers cathedral stress. Blanche and I, we must achieve this harmony. As Voltaire said, 'Perfection is attained by slow degrees.' This is our method."

---

## Grégoire "The Wildcat" Munster

- **Vocabulary Level**: Chaotic mix of French, Luxembourgish, English. Casual, playful, occasionally mispronounced. Slang-heavy.

- **Sentence Structure**: Fragmented, rapid-fire, stream-of-consciousness. Changes languages mid-sentence. Unfinished thoughts as new ones arrive. Enthusiastic chaos.

- **Verbal Tics**:
  - "ALLONS-Y!" (Let's go!)
  - "If it's not sideways, I'm not trying hard enough."
  - "Brother!" (borrowed from Sami)
  - Language mixing: "That was très sick, you know?"
  - "Quackers says..." (his rubber duck offering opinions)
  - Giggles mid-sentence

- **Emotional Expression**: Pure joy and enthusiasm. Grins audible in voice. Laughs during chaos descriptions. Never sounds stressed—everything is adventure. Exclamation points in verbal form constantly.

- **Influence**: Luxembourg multilingualism, youth culture, social media speech patterns. Rally is playground, not job—language reflects playfulness. English is third language (French/Luxembourgish primary), creates charming errors.

**Example dialogue**:
"So listen, LISTEN—we're going through this section, right? Completely flat, and Louis is like 'Grégoire, please, let's not crash today' but I'm thinking, Quackers would want me to send it, so BOOM! Full sideways! Sparks everywhere! C'était magnifique! The car, she was dancing! Malcolm will be... ah... maybe a little bit angry? But worth it, brother. Totally worth."

---

## Akira "Echo" Sato

- **Vocabulary Level**: Precise, technical, calm. Rally terminology perfectly deployed. Slightly formal like Kuro but warmer.

- **Sentence Structure**: Medium-length sentences with perfect rhythm. Pacenote delivery creates musical cadence that carries into regular speech. Measured, methodical.

- **Verbal Tics**:
  - Pacenote rhythm in regular speech: "Right-4, tightens, 100 to finish"
  - "Kuro says..." (frequent reference)
  - "Echo confirms" (habit from radio calls)
  - Quiet "Hai" (yes) of agreement
  - Perfect pitch maintenance even in conversation

- **Emotional Expression**: Restrained but warmer than Kuro. Allows small smiles. Pride in Kuro's success audible in tone. Concern shows through slight urgency in voice. Never panics—calm is professional requirement.

- **Influence**: Japanese formality, co-driver precision, 15-year partnership creating shorthand. English is flawless but retains Japanese prosody. Rhythm is everything—speech has metronomic quality.

**Example dialogue**:
"The stage notes indicate challenging conditions ahead. Kuro has reviewed them forty-seven minutes as expected. I confirm hybrid deployment strategy is optimal for sector three. We are prepared. Echo confirms readiness."

---

## Enni "Calculator" Mälkönen

- **Vocabulary Level**: Technical, mathematical, exasperated. Uses numbers and calculations naturally. Dry humor emerging.

- **Sentence Structure**: Precise, logical, efficient. Delivers information in prioritized order. Conditional statements ("If X, then Y"). Exasperation creates shorter, sharper sentences.

- **Verbal Tics**:
  - "CALM, CALM!" (signature phrase to Sami)
  - Numbers everywhere: "Seventeen percent tire degradation"
  - "Calculating..." (while doing mental math)
  - "Sami. We discuss this later."
  - Dry observations: "Interesting definition of 'calm'"
  - Deep sighs (audible in tone)

- **Emotional Expression**: Controlled exasperation. Eye-rolls audible in voice. Fondness hidden under irritation. Rapid-fire delivery under stress. Occasional Finnish curse words when Sami is impossible. Rarely shouts—precision even in anger.

- **Influence**: Mathematics PhD background, Finnish directness, co-driver communication training. English is technical precision tool. Green-tinted glasses metaphorically color worldview—everything has calculation.

**Example dialogue**:
"Sami, listen carefully. Tire degradation is seventeen-point-three percent above optimal. Fuel consumption suggests you are using twenty-two percent more throttle than necessary. If you continue this trajectory, we will need tire change at service, costing forty-seven seconds. So. CALM. CALM. Please. I am calculating how to keep us alive."

---

## Martijn "The Monk" Wydaeghe

- **Vocabulary Level**: Calm, reassuring, measured. Buddhist philosophy influences word choice. Belgian-accented English.

- **Sentence Structure**: Smooth, flowing sentences. Reassuring cadence. Uses breathing rhythm to pace speech. Never hurried.

- **Verbal Tics**:
  - "OK Thierry, we are fine, concentrate."
  - "Breathe. Focus. Execute."
  - "This too shall pass" (Buddhist influence)
  - "We are fine" (constant reassurance)
  - Frameless glasses adjustment pause
  - Belgian-accented English: "We make the good choices"

- **Emotional Expression**: Serene calm regardless of chaos. Thierry's panic met with unwavering steadiness. Encouragement through tone rather than words. Never raises voice. Smile audible in supportive moments.

- **Influence**: Buddhist meditation practice, Belgian multilingualism, years managing Thierry's emotions. English has Belgian lilt. Speech has meditative quality—grounding presence through voice alone.

**Example dialogue**:
"OK Thierry, listen to me now. We are fine. The car is good. You are good. Breathe with me—in, out. The next corner is right-4, but first, we center ourselves. Your passion is strength, but now we channel it with precision. We are fine. We concentrate. We execute. Yes?"

---

## Martin "The Viking" Järveoja

- **Vocabulary Level**: Minimal, technical, multilingual. Estonian/Russian terms mixed with English. Blunt efficiency.

- **Sentence Structure**: Short, declarative sentences matching Ott's style. Subject-verb-object simplicity. Occasional Estonian sentence structure.

- **Verbal Tics**:
  - Single raised eyebrow (visible in tone somehow)
  - Estonian/Russian mixed phrases: "Da, is good"
  - "Noted." (complete response)
  - Silence as full answer
  - Viking beard-stroking pause
  - Minimal acknowledgments: "Mm."

- **Emotional Expression**: Stoic exterior with rare warmth for Ott. Loyalty conveyed through minimal words. Protectiveness shows in slight edge when discussing rivals. Never wastes emotional energy on drama.

- **Influence**: Estonian/Russian bilingualism, Viking aesthetic, 2015-present partnership with Ott creating synchronized minimalism. English is functional. Six languages mean he can be silent in multiple tongues.

**Example dialogue**:
"Stage is ready. Ott is ready. Viking beard is braided. This is all preparation required. Now we drive. Win. Repeat." [If pressed]: "What more is necessary to say?"

---

## Alexandre "The Oracle" Coria

- **Vocabulary Level**: Sophisticated, philosophical, encouraging. Veteran wisdom. French academic influence.

- **Sentence Structure**: Flowing, supportive sentences. Philosophical observations. Metaphorical guidance. Descartes quotes integrated naturally.

- **Verbal Tics**:
  - "The Oracle sees..." (half-joking self-reference)
  - Descartes quotes: "I think, therefore I rally"
  - "As predicted..." (gentle I-told-you-so)
  - Wireframe glasses adjustment pause
  - "Consider this perspective..."
  - "Fascinating" (genuine intellectual interest)

- **Emotional Expression**: Encouraging warmth. Pride in Adrien's growth audible. Philosophical observations delivered with gentle humor. Patient teacher tone. Celebration is knowing smile in voice.

- **Influence**: Philosophy education, veteran navigator experience, French intellectual tradition. English has academic precision with French philosophical framing. Sees patterns others miss—speech reflects pattern recognition.

**Example dialogue**:
"Adrien, consider this: I predicted your potential three years ago when others doubted. The Oracle sees not fortune, but probability based on observed talent. Today you prove what I knew—that intellect and passion, properly channeled, defeat raw budget. As Descartes taught, clear thinking precedes correct action. You thought clearly. Therefore, you won."

---

## Louis "The Professor" Louka

- **Vocabulary Level**: Academic, patient, increasingly exasperated. Engineering terminology. Educational tone.

- **Sentence Structure**: Careful explanations. Engineering logic. Patient repetition when Grégoire ignores advice. Exasperation creates fragments.

- **Verbal Tics**:
  - "Grégoire, please, let's not crash today, OK?"
  - "I am documenting this." (journal threat)
  - "From engineering perspective..."
  - Deep sighs (frequent)
  - "Entry eight-hundred-forty-seven..." (journal reference)
  - "Why? Simply... why?" (existential question)

- **Emotional Expression**: Patient teacher tone cracking under Grégoire's chaos. Exasperation battles fondness constantly. Concern shows through extra precision in warnings. Rare pride when Grégoire listens (actual shock audible).

- **Influence**: Engineering education, three years managing Grégoire creating battle-worn patience. English has academic precision undermined by regular disbelief. Speech patterns document chaos while accepting it.

**Example dialogue**:
"Grégoire. Listen carefully. From engineering perspective, driving through sheep flock at competition speed violates approximately seventeen safety protocols and basic common sense. I am documenting this as journal entry eight-hundred-forty-seven. Why? Simply, why do you—[sigh]—never mind. Just... please. Let us not crash today. OK? Please?"

---

## Supporting Cast Speech Patterns

### Malcolm Wilson (M-Sport Team Principal)
- **Style**: Exasperated British father-figure. "Gentlemen, I'm getting too old for this." Dry wit masking genuine affection. Yorkshire accent thickens with stress. Tea references constant.

### Jari-Matti Latvala (Toyota Team Principal)  
- **Style**: Calm Finnish strategic thinking. "We analyze data, make correction, improve." Former champion's confidence. Measured rally wisdom. Slight Finnish accent.

### Cyril Abiteboul (Hyundai Team Principal)
- **Style**: Passionate French political maneuvering. "We must consider all variables!" Dramatic gestures audible in voice. Strategic thinking verbalized constantly.