# CWRC Character Profiles

## Kuro "The Shadow" Nakamura

- **Description**: Bombay cat, jet-black fur with supernatural sheen that absorbs light. Copper-gold eyes that glow intensely. Distinctive white whisker pattern on left cheek. Lean and muscular build, 5'10", 165 lbs. Age 29. Wears custom black Nomex racing suit with red GR stitching. Long fingers evolved for precise throttle control.

- **Role**: Toyota Gazoo Racing #1 driver. Two-time defending CWRC Champion (2023-2024). Team leader and precision benchmark. Currently 2nd in 2026 championship.

- **Personality**: Methodical, calculating, emotionally restrained. Values consistency over spectacular heroics. Obsessive about preparation and ritual. Respects opponents through silent acknowledgment rather than words. Deep well of competitive fire hidden beneath calm exterior. Uncomfortable with attention despite superstar status.

- **Quirks**: Studies stage notes for exactly 47 minutes (never 46, never 48). Drinks matcha from specific ceramic cup before starting car. Closes eyes for precisely three seconds before stage start. Never celebrates until final stage is complete. Keeps omamori (Japanese amulet) from Ise Grand Shrine in helmet. Wraps tail tightly around waist for aerodynamics. Misses old matte black livery intensely.

- **Goals**: Three-peat championship to cement legacy. Perfect the geometric racing line. Honor Toyota's kaizen philosophy through continuous improvement. Prove consistency defeats raw speed. Eventually retire undefeated (secret aspiration).

- **Relationships**: 
  - **Akira Sato (co-driver):** Childhood friend, 15-year partnership, communicate via minimalist shorthand
  - **Sami Pajari:** Teammate, subtle tension between youth/experience, respects Sami's speed but questions consistency
  - **Ott Tänak:** Primary championship rival, mutual respect through shared precision philosophy
  - **Thierry Neuville:** Respects passion but considers it inefficient
  - **Toyota team:** Loyal soldier to corporate structure, embodies brand values

---

## Sami "Wildcard" Pajari

- **Description**: Bombay cat, younger and smaller than Kuro. Matte-textured black fur lacking supernatural gloss. Copper eyes burning with youthful fire. Distinctive notch in right ear from karting accident. Compact and powerful, 5'8", 155 lbs. Age 23. Rolls racing suit sleeves to elbows during recce. Shorter-than-average tail (jokes it's "more aerodynamic").

- **Role**: Toyota Gazoo Racing #2 driver. 2025 WRC2 Champion promoted to Rally1. Wild card bringing raw speed and fearlessness. Currently 5th in championship but fastest on raw pace.

- **Personality**: Aggressive, enthusiastic, impulsive. Lives for sideways moments and spectacular driving. Wears emotions openly—grins maniacally during chaos, cries openly after heartbreak. Competitive fire burns hot, sometimes too hot. Learning consistency from Kuro (resents this learning curve). Calls everyone "brother" or "sister."

- **Quirks**: Grins during muddy stages. Compulsively adjusts rear-view mirror between stages. Listens to death metal at dangerous volumes during transits. Makes engine noises under breath when analyzing onboards. Constantly snacking on kalakukko (Finnish fish pie). Blasts Children of Bodom before stages.

- **Goals**: Win first Rally1 championship. Prove raw speed beats calculated precision. Make Finland proud. Eventually beat Kuro (complicated teammate dynamics). Master tarmac to match gravel dominance.

- **Relationships**:
  - **Enni Mälkönen (co-driver):** Bicker like siblings, complete trust despite arguments
  - **Kuro Nakamura:** Teammate, learning from him but also competing against him, wants respect
  - **Ott Tänak:** Rival who beat him by 0.3s in Poland (devastating heartbreak)
  - **Grégoire Munster:** Kindred spirit in chaos, "who can get more sideways" competitions
  - **Toyota team:** Sometimes frustrates engineers with aggression, but they love his passion

---

## Thierry "The Warrior" Neuville

- **Description**: Korat cat, silver-tipped blue-grey fur with phosphorescent shimmer. Luminous green eyes radiating competitive intensity. Small scar above left eyebrow from 2018 Corsica crash. Tall and athletic, 6'0", 178 lbs. Age 36. Powerful forearms from touring car background. Silver-tipped tail creates distinctive plume. Racing suit features iconic #11 in metallic orange.

- **Role**: Hyundai Shell Mobis WRT #11 driver. 2025 CWRC Champion (finally!). Emotional heart of Hyundai team. Currently 3rd in 2026 championship, fighting to defend title.

- **Personality**: Passionate, aggressive, emotional. Wears heart on sleeve—celebrates wildly, rages intensely. Competitive fire is his defining trait. Years of championship heartbreak created chip on shoulder. Tarmac specialist who attacks corners with Belgian fury. Refuses to accept second place as acceptable outcome.

- **Quirks**: Stares unblinking at rivals during briefings. Refuses pre-rally handshakes (only after—"respect is earned"). Obsessively polishes helmet visor between service. Speaks French-Flemish hybrid when angry. Celebrates stage wins with Korat howl that echoes through service parks. Keeps all 156+ podium champagne corks in display case.

- **Goals**: Defend 2025 championship (first title took until age 35—desperate to prove it wasn't fluke). Beat Ott Tänak (primary rival). Win on pure aggression, not calculated precision. Make Belgium proud. Eventually retire as multi-time champion.

- **Relationships**:
  - **Martijn Wydaeghe (co-driver):** Zen counterbalance, married to Thierry's cousin, won 2025 championship together
  - **Ott Tänak:** Teammate but fierce rival, competitive tension barely controlled
  - **Kuro Nakamura:** Respects precision but considers it "too cold"
  - **Adrien Fourmaux:** Gave genuine compliment after Croatia loss—"drove like Belgian"
  - **Hyundai team:** Emotional leader, passion energizes entire squad

---

## Ott "The Ice King" Tänak

- **Description**: Korat cat, darker slate-grey with less silver tipping than Thierry—"bruiser aesthetic." Pale jade-green eyes with distant, analytical appearance. Coarser facial fur from Estonian winters. Compact power, 5'11", 172 lbs. Age 37. Exceptional core strength from ice-hockey training. Unusually thick, muscular tail. Pristine but functional racing suit.

- **Role**: Hyundai Shell Mobis WRT #12 driver. 2019 CWRC Champion (with M-Sport). Consistency machine and tactical genius. Currently leading 2026 championship by 50 points.

- **Personality**: Brutally efficient, emotionally minimal, supremely confident. Speaks in economical sentences (entire interviews under 30 words). Never wastes energy on unnecessary actions. Finds time where others think none exists. Occasional motivational lapses on rallies he dislikes. Zero interest in public relations—racing is job, not performance.

- **Quirks**: Never smiles for photographs ("face might crack"). Eats identical pre-rally meal: boiled potatoes, pickled herring, rye bread. Personally checks tire pressures (doesn't fully trust mechanics). Stores setup notes in locked briefcase. Has never said "thank you" to media (only to team). Complete silence for 15 minutes before stages.

- **Goals**: Second CWRC championship (proving 2019 wasn't fluke). Win through minimal effort and maximum efficiency. Eventually retire with dignity (no emotional farewells). Beat Thierry within same team (psychological advantage).

- **Relationships**:
  - **Martin Järveoja (co-driver):** Partnership since 2015, perfect synchronization, won 2019 together
  - **Thierry Neuville:** Teammate and rival, controlled tension, mutual respect grudgingly given
  - **Kuro Nakamura:** Recognizes kindred precision spirit, closest to "friend" he has
  - **Sami Pajari:** Respects raw speed, taught him lesson in Poland (0.3s victory)
  - **Hyundai team:** Professional relationship, delivers results, demands nothing

---

## Adrien "The Architect" Fourmaux

- **Description**: Turkish Van cat, chalk-white body with russet-and-cream markings on head ("cap pattern") and tail. Heterochromia—one amber eye, one bright blue (asymmetrical, mystical appearance). Tall and lean, 6'1", 170 lbs. Age 29. Water-resistant Van coat. Distinctive plumed tail (refuses to tuck during races). White racing suit with blue Castrol stripes and Red Bull accents.

- **Role**: M-Sport Ford WRT #4 driver. Rising star with two victories in 2026 (Croatia, Sardinia). Tarmac specialist and technical feedback master. Currently 4th in championship, surprising title contender.

- **Personality**: Analytical, intellectual, artistic. Treats racing as engineering problem requiring elegant solutions. Aerospace background informs geometric approach to corners. Speaks in architectural metaphors. Confidence growing with success but still wavers under pressure. Appreciates beauty in mechanical perfection.

- **Quirks**: Sketches optimal racing lines in leather-bound notebook. Speaks in architectural metaphors ("Gothic arch approach, not Brutalist"). Obsessed with aerodynamics, personally adjusts rear wing despite protests. Takes single sip of espresso before entering car (never finishes). Names each car (current is "Blanche"). Quotes French philosophers when frustrated.

- **Goals**: First CWRC championship (prove privateers can beat factories). Perfect the marriage of art and science in driving. Make M-Sport proud of investment. Prove heterochromia is advantage, not oddity. Eventually design rally cars after retirement.

- **Relationships**:
  - **Alexandre Coria (co-driver):** Veteran navigator who predicted Adrien's potential, calm guidance
  - **Grégoire Munster:** Teammate, opposite personalities, genuine friendship despite differences
  - **Thierry Neuville:** Mutual respect after Croatia battle, Thierry's compliment meant everything
  - **Malcolm Wilson (team principal):** Father-figure relationship, desperate to justify Malcolm's faith
  - **M-Sport team:** Feels family bond, knows limited resources make success sweeter

---

## Grégoire "The Wildcat" Munster

- **Description**: Turkish Van cat, asymmetrical markings concentrated on left side of head ("pirate look"). Both eyes bright amber, constantly scanning for opportunities. White coat accumulates spectacular dirt transformation during rallies. Compact and explosive, 5'9", 160 lbs. Age 26. Built like footballer with powerful legs. Distinctive kinked tail halfway down (calls it "gear lever"). Racing suit with prominent #3.

- **Role**: M-Sport Ford WRT #3 driver. Rising star and entertainment provider. "60% genius, 40% madman" per Malcolm Wilson. Currently 6th in championship but fastest on pure commitment.

- **Personality**: Fearless, joyful, chaotic. Grins constantly, even during crashes. Rally is adventure, not job. Willing to try impossible moves. Needs consistency development but provides spectacular moments. Social glue bringing levity to competitive tension. Challenges everyone to competitions (arm-wrestling record: 3-47).

- **Quirks**: Grins during crashes. Fist-bumps every M-Sport member every time. Keeps lucky rubber duck "Quackers" on dashboard. Speaks rapid-fire French/Luxembourgish/English mix. Does impromptu donuts when Malcolm isn't watching (he's always watching). Collects regional snacks, rates them on Instagram. Does 12 jumping jacks before stages.

- **Goals**: First Rally1 victory (prove he's not just entertaining, he's fast). Master consistency without losing joy. Make Luxembourg rally-famous. Eventually convince Malcolm to let him keep adopted cats (currently: 1, smuggled). Never lose the grin.

- **Relationships**:
  - **Louis Louka (co-driver):** Patient professor tempering chaos, deep loyalty despite exasperation
  - **Adrien Fourmaux:** Teammate, opposite approach but genuine friendship
  - **Sami Pajari:** Kindred chaos spirit, "sideways competitions" 
  - **Malcolm Wilson:** Father-figure who tolerates antics with exasperated affection
  - **M-Sport team:** Beloved mascot who occasionally gives engineers heart attacks

---

## Akira "Echo" Sato (Kuro's Co-Driver)

- **Description**: Bombay cat, age 27, male. Similar appearance to Kuro but slightly smaller build. Wears glasses with polarized lenses to reduce glare. Impeccable posture matching Kuro's discipline.

- **Role**: Kuro's co-driver and childhood friend from Nagoya. Navigator with metronomic consistency. 15-year partnership creates nearly telepathic communication.

- **Personality**: Calm, precise, loyal. Delivers pacenotes with perfect pitch and rhythm. Understands Kuro's minimalist communication perfectly. Secretly romantic about their partnership. Quietly proud of Kuro's success.

- **Quirks**: Delivers pacenotes so rhythmically teammates call it "Echo effect." Keeps secret diary of Kuro's rare emotional moments (7 entries in 5 years). Wears different shrine omamori each rally. Adjusts glasses precisely before each stage.

- **Goals**: Help Kuro achieve three-peat championship. Maintain perfect pacenote delivery record (currently: zero mistakes in 8 years). Eventually write book about partnership (never will—too private).

- **Relationships**:
  - **Kuro Nakamura:** Childhood friend, can predict his thoughts, platonic life partnership
  - **Enni Mälkönen:** Professional respect, shares co-driver challenges
  - **Toyota team:** Respected for consistency, slightly mysterious to outsiders

---

## Enni "Calculator" Mälkönen (Sami's Co-Driver)

- **Description**: Bombay cat, age 24, female. Petite build with intense expression. Signature green-tinted driving glasses. Mathematics prodigy with sharp features that soften when she smiles (rarely during rallies).

- **Role**: Sami's co-driver and impulse control. Mathematics PhD dropout who chose rallying over academia. Can calculate fuel consumption, tire degradation, and time gaps mentally mid-stage.

- **Personality**: Brilliant, exasperated, secretly fond. Acts as Sami's brakes—the caution he lacks. Delivers rapid-fire pacenotes with mathematical precision. Bickers with Sami constantly but trusts him completely. Dry sense of humor emerges in radio calls ("CALM, CALM").

- **Quirks**: Calculates complex math mentally during stages. Tells Sami to "CALM, CALM" multiple times per rally. Green-tinted glasses never removed (superstition). Keeps meticulously color-coded pacenote books. Secretly enjoys Sami's chaos but never admits it.

- **Goals**: Keep Sami alive and winning. Eventually get him to listen to "CALM, CALM" before needing it. Win championship together. Publish mathematics paper about optimal racing lines (side project).

- **Relationships**:
  - **Sami Pajari:** Sibling-like dynamic, complete trust despite arguments, protective of his potential
  - **Akira Sato:** Professional respect, shares co-driver bond
  - **Toyota team:** Appreciated as "Sami's brain"

---

## Martijn "The Monk" Wydaeghe (Thierry's Co-Driver)

- **Description**: Korat cat, age 38, male. Calm features with distinctive frameless glasses. Practiced Buddhist meditation creates serene aura. Well-groomed appearance contrasting Thierry's warrior intensity.

- **Role**: Thierry's co-driver and emotional anchor. Zen counterbalance to Belgian passion. Married to Thierry's cousin (family dynamics add complexity). Won 2025 championship together after years of heartbreak.

- **Personality**: Calm, wise, patient. Uses Buddhist meditation techniques to manage Thierry's emotions. Delivers pacenotes in steady, measured Belgian-accented English. Known for calming "OK Thierry, we are fine, concentrate" during aggressive moments. Deeply loyal through championship drought.

- **Quirks**: Meditates before stages while Thierry paces. Signature phrase: "OK Thierry, we are fine, concentrate." Collects miniature rally car models (400+ collection). Adjusts frameless glasses with precise ritual. Never raises voice, even during crashes.

- **Goals**: Defend 2025 championship with Thierry. Keep Thierry focused during emotional moments. Eventually retire together at peak. Complete rally car model collection (seeking rare 1983 Audi Quattro).

- **Relationships**:
  - **Thierry Neuville:** Partnership since 2021, emotional management specialist, family connection through cousin
  - **Martin Järveoja:** Professional respect between veteran co-drivers
  - **Hyundai team:** Calming presence, appreciated as "Thierry whisperer"

---

## Martin "The Viking" Järveoja (Ott's Co-Driver)

- **Description**: Korat cat, age 37, male. Estonian with Russian heritage. Distinctive Viking beard (well-groomed fur styling). Stoic features hiding deep loyalty. Powerful build matching Ott's compact strength.

- **Role**: Ott's co-driver since 2015. Navigator who understands minimalist communication. Won 2019 championship together. Speaks 6 languages fluently. Keeps detailed technical notes worth millions.

- **Personality**: Stoic, loyal, brilliant. Delivers concise Estonian pacenotes with occasional Russian terms. Understands Ott's minimal communication perfectly. Projects quiet competence. Never seeks spotlight—content being Ott's shadow.

- **Quirks**: Viking beard braided before each rally (superstition). Speaks 6 languages, uses all during international service parks. Keeps locked technical database. Rarely shows emotion but fiercely protective of Ott. Single raised eyebrow is maximum emotional expression.

- **Goals**: Second championship with Ott (proving 2019 wasn't luck). Perfect the synchronized silence with Ott. Eventually retire together (unspoken agreement). Protect technical notes from rival teams.

- **Relationships**:
  - **Ott Tänak:** Partnership since 2015, perfect synchronization, closest thing Ott has to friend
  - **Martijn Wydaeghe:** Veteran co-driver respect, occasional database sharing
  - **Hyundai team:** Professional relationship, delivers results quietly

---

## Alexandre "The Oracle" Coria (Adrien's Co-Driver)

- **Description**: Turkish Van cat, age 33, male. Distinguished features with signature wireframe glasses. Former philosophy student with intellectual bearing. Meticulously organized appearance.

- **Role**: Adrien's co-driver and veteran navigator (third WRC driver partnership). Predicted Adrien's potential before anyone—"the Oracle sees." Maintains personal database of every WRC corner.

- **Personality**: Wise, encouraging, analytical. Delivers smooth French pacenotes with occasional English terms. Provides calm guidance to Adrien's intellectual intensity. Former philosophy student who quotes Descartes during difficult moments. Patient educator helping Adrien build confidence.

- **Quirks**: Predicted Adrien's victories before they happened (team calls him Oracle). Keeps color-coded pace-note book with obsessive annotations. Quotes Descartes during problems ("I think, therefore I rally"). Wireframe glasses polished to perfection. Maintains database of every WRC corner (personal project).

- **Goals**: Help Adrien win championship (prove Oracle's prediction correct). Perfect the pace-note database. Eventually write philosophical treatise on rally navigation. Retire after Adrien's first title.

- **Relationships**:
  - **Adrien Fourmaux:** Third driver partnership, saw potential first, mentor-student dynamic
  - **Louis Louka:** M-Sport co-driver bond, share setup data
  - **M-Sport team:** Veteran presence providing institutional knowledge

---

## Louis "The Professor" Louka (Grégoire's Co-Driver)

- **Description**: Turkish Van cat, age 28, male. Engineering graduate with scholarly appearance. Signature round glasses. Patient expression frequently tested by Grégoire's chaos. Neat appearance despite rally environment.

- **Role**: Grégoire's co-driver and impulse control (attempts at). Engineering graduate teaching racecraft through patience. Keeps detailed journal of Grégoire's wild moments (847 entries and counting).

- **Personality**: Patient, intelligent, exasperated. Delivers calm, academic-toned pacenotes even during chaos. Known for signature phrase: "Grégoire, please, let's not crash today, OK?" Engineering background provides technical feedback. Secretly admires Grégoire's fearless spirit while worrying constantly.

- **Quirks**: Signature phrase said multiple times per rally. Keeps extensive journal of Grégoire's moments (847 entries). Round glasses constantly adjusted after Grégoire's aggressive driving. Maintains detailed setup databases. Deep sighs audible on team radio.

- **Goals**: Keep Grégoire alive and competitive. Eventually get him to listen before trying impossible moves. Win rally together through teamwork. Complete engineering thesis on optimal chaos management (joke that's becoming real).

- **Relationships**:
  - **Grégoire Munster:** Long-suffering partnership, deep loyalty despite chaos, genuine friendship
  - **Alexandre Coria:** M-Sport co-driver bond, shares "managing creative drivers" strategies
  - **M-Sport team:** Provides engineering insights, apologizes for Grégoire regularly

---

## Supporting Cast

### Jari-Matti "JM" Latvala (Toyota Team Principal)
- **Description**: Human, Finnish, age 52. Former rally champion turned team principal. Calm, strategic, deeply experienced.
- **Role**: Toyota Gazoo Racing team principal. Manages Kuro and Sami's contrasting styles. Makes strategic calls during rallies.

### Dr. Kenji Nakamura (Toyota Technical Director)
- **Description**: Human, Japanese, age 58. Engineering perfectionist embodying kaizen philosophy.
- **Role**: Toyota technical director. Develops car setups. Works closely with Kuro on precision optimization.

### Cyril Abiteboul (Hyundai Team Principal)
- **Description**: Human, French, age 49. Passionate, political, strategic thinker.
- **Role**: Hyundai Shell Mobis WRT team principal. Manages Ott and Thierry's rivalry. Navigates team politics.

### Malcolm Wilson (M-Sport Team Principal)
- **Description**: Human, British, age 61. Rally legend turned privateer team owner. Exasperated father-figure.
- **Role**: M-Sport Ford WRT team principal and owner. Maximizes limited budget through genius and experience. Tolerates Grégoire's chaos with affectionate frustration.